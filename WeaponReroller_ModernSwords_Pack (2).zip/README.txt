WeaponReroller - Modern 3D Swords  (resource pack for Minecraft Java 1.21.11)

11 hand-built 3D sword models, one per WeaponReroller sword, all sharing a dark "modern netherite" base
with a different theme/silhouette each. Glowing parts render fullbright (light_emission).

Models live at assets/weaponreroller/items/<sword_id>.json  (ids: dash_sword, crimson_swipe, daybreak,
fortunes_keep, soul_eater, wardens_cry, frostbite, gravebinder, emberfall, phantom_edge, stormcaller).
The patched WeaponReroller plugin sets each sword's `item_model` to  weaponreroller:<sword_id>.

SERVER: host this zip somewhere public, then in server.properties set
    resource-pack=<direct download url of the zip>
    resource-pack-sha1=<sha1 of the zip>      (sha1sum file.zip)
    require-resource-pack=true                 (optional)
SINGLE-PLAYER / TESTING: drop the zip into .minecraft/resourcepacks and enable it.
